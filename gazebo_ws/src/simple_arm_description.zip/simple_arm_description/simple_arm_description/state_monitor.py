import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

TARGETS = ['joint1_z', 'joint1_y', 'joint2', 'joint3']


class StateMonitor(Node):
    def __init__(self):
        super().__init__('state_monitor')
        self.create_subscription(
            JointState,
            '/joint_states',
            self.callback,
            10
        )

    def callback(self, msg):
        data = {n: (p, v) for n, p, v in
                zip(msg.name, msg.position, msg.velocity)}
        for name in TARGETS:
            if name not in data:
                continue
            pos, vel = data[name]
            self.get_logger().info(
                f'[state_monitor] {name:<10} pos: {pos:.3f}  vel: {vel:.3f}'
            )


def main():
    rclpy.init()
    node = StateMonitor()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
