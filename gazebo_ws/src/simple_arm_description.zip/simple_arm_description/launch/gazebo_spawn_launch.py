import os
import re

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import xacro


def generate_launch_description():
    pkg = "simple_arm_description"
    pkg_share = get_package_share_directory(pkg)

    urdf_path = os.path.join(pkg_share, "urdf", "simple_arm.urdf.xacro")

    # Gazebo Classic 실행
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory("gazebo_ros"),
                "launch",
                "gazebo.launch.py",
            )
        )
    )

    # robot_description에 URDF(xacro) 내용(문자열) 넣기
    robot_desc = xacro.process_file(urdf_path).toxml()

    # Strip XML comments so gazebo_ros2_control can parse the CLI param override.
    robot_desc = re.sub(r"<!--.*?-->", "", robot_desc, flags=re.DOTALL)
    robot_desc = " ".join(robot_desc.split())

    rsp = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[{
            "robot_description": robot_desc,
            "use_sim_time": True,
        }],
    )

    # Gazebo에 스폰
    spawn = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        output="screen",
        arguments=[
            "-entity", "simple_arm",
            "-topic", "robot_description",
            "-x", "0.0", "-y", "0.0", "-z", "0.0",
        ],
    )

    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager", "/controller_manager",
        ],
    )

    joint_trajectory_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=[
            "joint_trajectory_controller",
            "--controller-manager", "/controller_manager",
        ],
    )

    effort_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=[
            "effort_controller",
            "--controller-manager", "/controller_manager",
            "--inactive",
        ],
    )

    return LaunchDescription([
        gazebo,
        rsp,
        spawn,
        joint_state_broadcaster_spawner,
        joint_trajectory_controller_spawner,
        effort_controller_spawner,
    ])